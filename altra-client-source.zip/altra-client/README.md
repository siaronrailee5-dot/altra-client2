# Altra Client (v0.1, Fabric 1.21.1, client-only)

## Build
1. Install JDK 21 and Gradle (or add the Gradle wrapper: `gradle wrapper`).
2. In this folder run: `gradle build`
3. Take `build/libs/altra-client-0.1.0.jar` and put it in your `.minecraft/mods` folder
   together with Fabric API and (recommended) Sodium, Lithium, FerriteCore, Entity Culling.

## Use
- Press Right Shift in game to open the Altra menu.
- HUD: FPS, ping, CPS.  Particle limiter: crit, damage, enchant hit, sweep.
- 3D Skin Preview: live model of your skin.

No reach, hitbox, velocity, or packet changes. Safe on servers.
