package com.altra.client;

import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;

/** Counts left-clicks in the last second. Polled every client tick (cheap). */
public class CpsTracker {
    private static final ArrayDeque<Long> CLICKS = new ArrayDeque<>();
    private static boolean wasDown = false;

    public static void tick(long window) {
        boolean down = GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        long now = System.currentTimeMillis();
        if (down && !wasDown) CLICKS.addLast(now);
        wasDown = down;
        while (!CLICKS.isEmpty() && now - CLICKS.peekFirst() > 1000) CLICKS.pollFirst();
    }

    public static int get() {
        return CLICKS.size();
    }
}
