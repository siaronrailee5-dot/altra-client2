package com.altra.client.gui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

/** Live 3D preview of your current skin. The model follows the cursor. */
public class SkinPreviewScreen extends Screen {
    private final Screen parent;

    public SkinPreviewScreen(Screen parent) {
        super(Text.literal("3D Skin Preview"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        addDrawableChild(ButtonWidget.builder(Text.literal("Back"),
                b -> close()).dimensions(width / 2 - 50, height - 30, 100, 20).build());
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, 0xFF12141A);
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, "3D Skin Preview", width / 2, 12, 0xFFFFB347);

        if (client != null && client.player != null) {
            int cx = width / 2, size = Math.min(height / 3, 90);
            InventoryScreen.drawEntity(ctx, cx - 80, 30, cx + 80, height - 40, size, 0.0625F,
                    mouseX, mouseY, client.player);
        }
    }

    @Override
    public void close() {
        client.setScreen(parent);
    }
}
