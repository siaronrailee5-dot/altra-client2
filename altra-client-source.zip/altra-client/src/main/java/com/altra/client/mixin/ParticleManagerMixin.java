package com.altra.client.mixin;

import com.altra.client.AltraConfig;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Client-only: skips spawning selected combat particles. Purely visual, no gameplay effect. */
@Mixin(ParticleManager.class)
public class ParticleManagerMixin {
    @Inject(method = "addParticle(Lnet/minecraft/particle/ParticleEffect;DDDDDD)Lnet/minecraft/client/particle/Particle;",
            at = @At("HEAD"), cancellable = true)
    private void altra$filter(ParticleEffect effect, double x, double y, double z,
                              double vx, double vy, double vz, CallbackInfoReturnable<Particle> cir) {
        AltraConfig c = AltraConfig.INSTANCE;
        if ((c.hideCritParticles && effect.getType() == ParticleTypes.CRIT)
                || (c.hideDamageParticles && effect.getType() == ParticleTypes.DAMAGE_INDICATOR)
                || (c.hideEnchantHitParticles && effect.getType() == ParticleTypes.ENCHANTED_HIT)
                || (c.hideSweepParticles && effect.getType() == ParticleTypes.SWEEP_ATTACK)) {
            cir.setReturnValue(null);
        }
    }
}
