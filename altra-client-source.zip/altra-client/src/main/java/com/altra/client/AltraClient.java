package com.altra.client;

import com.altra.client.gui.AltraScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class AltraClient implements ClientModInitializer {
    private static KeyBinding menuKey;

    @Override
    public void onInitializeClient() {
        AltraConfig.load();

        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.altra.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.altra"));

        HudRenderCallback.EVENT.register((ctx, tickCounter) -> AltraHud.render(ctx));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            CpsTracker.tick(mc.getWindow().getHandle());
            while (menuKey.wasPressed()) mc.setScreen(new AltraScreen(mc.currentScreen));
        });
    }
}
