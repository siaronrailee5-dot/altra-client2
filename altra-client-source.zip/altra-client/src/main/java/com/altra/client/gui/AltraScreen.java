package com.altra.client.gui;

import com.altra.client.AltraConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.function.Supplier;
import java.util.function.Consumer;

/** Single flat settings screen: no blur, no animations. */
public class AltraScreen extends Screen {
    private final Screen parent;

    public AltraScreen(Screen parent) {
        super(Text.literal("Altra Client"));
        this.parent = parent;
    }

    private void toggle(int x, int y, String label, Supplier<Boolean> get, Consumer<Boolean> set) {
        addDrawableChild(ButtonWidget.builder(label(label, get.get()), b -> {
            set.accept(!get.get());
            b.setMessage(label(label, get.get()));
            AltraConfig.save();
        }).dimensions(x, y, 150, 20).build());
    }

    private static Text label(String name, boolean on) {
        return Text.literal(name + ": " + (on ? "ON" : "OFF"));
    }

    @Override
    protected void init() {
        AltraConfig c = AltraConfig.INSTANCE;
        int left = width / 2 - 155, right = width / 2 + 5, y = 40;

        toggle(left, y, "HUD", () -> c.showHud, v -> c.showHud = v);
        toggle(right, y, "FPS", () -> c.showFps, v -> c.showFps = v);
        y += 24;
        toggle(left, y, "Ping", () -> c.showPing, v -> c.showPing = v);
        toggle(right, y, "CPS", () -> c.showCps, v -> c.showCps = v);
        y += 34;
        toggle(left, y, "Hide crit particles", () -> c.hideCritParticles, v -> c.hideCritParticles = v);
        toggle(right, y, "Hide damage particles", () -> c.hideDamageParticles, v -> c.hideDamageParticles = v);
        y += 24;
        toggle(left, y, "Hide enchant hit", () -> c.hideEnchantHitParticles, v -> c.hideEnchantHitParticles = v);
        toggle(right, y, "Hide sweep", () -> c.hideSweepParticles, v -> c.hideSweepParticles = v);
        y += 34;

        addDrawableChild(ButtonWidget.builder(Text.literal("3D Skin Preview"),
                b -> client.setScreen(new SkinPreviewScreen(this))).dimensions(width / 2 - 75, y, 150, 20).build());
        y += 28;
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"),
                b -> close()).dimensions(width / 2 - 75, y, 150, 20).build());
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, 0xCC12141A);
        ctx.drawCenteredTextWithShadow(textRenderer, "Altra Client", width / 2, 16, 0xFFFFB347);
        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override
    public void close() {
        client.setScreen(parent);
    }
}
