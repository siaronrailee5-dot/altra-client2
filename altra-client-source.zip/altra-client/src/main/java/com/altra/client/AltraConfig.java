package com.altra.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

public class AltraConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("altra.json");

    public static AltraConfig INSTANCE = new AltraConfig();

    public boolean showHud = true;
    public boolean showFps = true;
    public boolean showPing = true;
    public boolean showCps = true;
    public boolean hideCritParticles = false;
    public boolean hideDamageParticles = false;
    public boolean hideEnchantHitParticles = false;
    public boolean hideSweepParticles = false;

    public static void load() {
        try {
            if (Files.exists(FILE)) {
                INSTANCE = GSON.fromJson(Files.readString(FILE), AltraConfig.class);
                if (INSTANCE == null) INSTANCE = new AltraConfig();
            }
        } catch (Exception e) {
            INSTANCE = new AltraConfig();
        }
    }

    public static void save() {
        try {
            Files.writeString(FILE, GSON.toJson(INSTANCE));
        } catch (Exception ignored) {}
    }
}
