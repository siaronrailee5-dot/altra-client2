package com.altra.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;

import java.util.ArrayList;
import java.util.List;

/** Tiny text HUD. No textures, no blur: costs almost nothing per frame. */
public class AltraHud {
    public static void render(DrawContext ctx) {
        AltraConfig cfg = AltraConfig.INSTANCE;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!cfg.showHud || mc.options.hudHidden || mc.player == null || mc.getDebugHud().shouldShowDebugHud()) return;

        List<String> lines = new ArrayList<>(3);
        if (cfg.showFps) lines.add("FPS " + mc.getCurrentFps());
        if (cfg.showPing) {
            int ping = 0;
            if (mc.getNetworkHandler() != null) {
                PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
                if (e != null) ping = e.getLatency();
            }
            lines.add("Ping " + ping + " ms");
        }
        if (cfg.showCps) lines.add("CPS " + CpsTracker.get());

        int y = 6;
        for (String s : lines) {
            ctx.drawTextWithShadow(mc.textRenderer, s, 6, y, 0xFFFFFFFF);
            y += 11;
        }
    }
}
